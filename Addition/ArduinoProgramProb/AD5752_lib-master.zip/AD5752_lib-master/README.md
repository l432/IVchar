# AD5752_lib
Arduino library for AD5752. Onlu basic functionality is implemented, but a good start
